/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * return entrega un resultado desde una función para utilizarlo donde se llamó.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
function saludar(nombre) {
  return  "Hola, " + nombre + ", soy la función crearSaludo";
}

console.log(crearSaludo("Maria"));


 /*crear un boton en html que llame a una funcion que muestre la edad. La edad se la pasas 
 por parammetro al llamar a la funcion*/


function edad() {

  let  edades = document.getElementById("edad").value;

    document.getElementById("mostrarEdad").textContent =

           "Mi edad es: " + edades;

           if(edades < 18){
               document.getElementById("mostrarEdad").textContent += " (Eres menor de edad)";
           }else{
               document.getElementById("mostrarEdad").textContent += " (Eres mayor de edad)";
           }



}

console.log (edades);

    function mostrarDatos() {

        let nombreDatos= saludar();
        let edadDatos= edad();

    
        document.getElementById("datos").textContent = "Nombre: " + nombreDatos + ", Edad: " + edadDatos;
    }





