/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
let nombre = "Ana";
let edad = 18;
let ciudad = "Madrid";


console.log (`Me llamo ${nombre}, tengo ${edad} años y vivo en ${ciudad}.`);

let hola = (`Hola, me llamo ${nombre}, tengo ${edad} años y vivo en ${ciudad}.`);

document.getElementById("hola").textContent = hola;






