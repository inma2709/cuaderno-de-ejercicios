/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * Los métodos de array se aplican sobre la colección: push añade, find localiza el primer resultado y filter crea una selección.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
// const productos = [
//   { nombre: "Ratón", precio: 15, cantidad: 2 },
//   { nombre: "Teclado", precio: 30, cantidad: 3 },
//   { nombre: "Monitor", precio: 150, cantidad: 4 }
// ];
// for (const producto of productos) {
//  console.log("este es el nombre de producto:"+ producto.nombre);
//  console.log (`este es el precio del producto: ${producto.precio} , este es la cantidad: ${producto.cantidad}`)
// }

// let contador = 0;
// for (const producto of productos){
//     if (producto.precio >20) {
//         contador++;
//     }
// }
// console.log("Cantidad de productos con precio mayor a 20: " + contador);
// /*busca el primer producto con precio mayor a 20 */
// const encontrado= productos.find(producto => producto.precio > 20);
// console.log(encontrado);
// /*busca todos los productos con precio mayor a 20 y nos devuelve un array con ellos */
// const productosCaros= productos.filter(producto => producto.precio > 20);
// console.log(productosCaros);
// for (const producto of productosCaros) {
//     console.log("Producto caro: " + producto.nombre);
// }

// productos.push({
//   nombre: "Impresora",
//   precio: 90,
//   cantidad: 2

// });
// console.log(productos);


// /*for in loop para mostrar las propiedades y valores del tercer producto */
// for (const propiedad in productos[2]) {
//   console.log("soy la propiedad y el valor: " + propiedad + ": " + productos[2][propiedad]);
// }
// /*aprendemos object key, object values y object entries */

let falda = {
  nombre:"Falda",
  cantidad:10,
  precio: 25
}
/*nos muestra las propiedades del objeto */
console.log(Object.keys(falda));

/*nos muestra los valores del objeto */
console.log(Object.values(falda));

/*nos muestra los pares [propiedad, valor] del objeto */
console.log(Object.entries(falda));




