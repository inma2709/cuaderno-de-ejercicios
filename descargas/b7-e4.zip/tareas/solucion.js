/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Al iniciar, se recuperan los datos guardados y se actualiza el array. Al añadir un dato: push(), guardar en localStorage y volver a mostrar el listado.
 * JSON.stringify convierte arrays u objetos en texto para guardarlos; JSON.parse recupera de nuevo su estructura.
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * Los valores de los inputs son texto. Number() los convierte a número antes de calcular.
 * Los métodos de array se aplican sobre la colección: push añade, find localiza el primer resultado y filter crea una selección.
 * return entrega un resultado desde una función para utilizarlo donde se llamó.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */

/*
  MI AGENDA DE TAREAS
  PRÁCTICA DE REPASO
*/


// =========================================
// RETO 1 · ARRAY DE TAREAS
// =========================================

let tareas = [
  { nombre: "Estudiar JavaScript", categoria: "Estudio", minutos: 120 },
  { nombre: "Hacer ejercicio", categoria: "Personal", minutos: 60 }
];

//esta linea es la última que incorporamos y lo hacemos 
//porque tenemos las tareas guardadas en el localstorage 
// y queremos que al recargar la página se muestren las tareas guardadas nuevas 
// y no las que tenemos en el array por defecto


tareas = recuperarTareasLocal() || tareas;

// =========================================
// RETO 1 · MOSTRAR LAS TAREAS
// =========================================

function mostrarTareas() {

  // Seleccionamos el contenedor del HTML
  const listaTareas = document.getElementById("listaTareas");

  // Limpiamos para no repetir las tarjetas
  listaTareas.innerHTML = "";

  // Recorremos el array
  for (const tarea of tareas) {

    listaTareas.innerHTML += `
      <article class="tarea">
        <h3>${tarea.nombre}</h3>
        <p>Categoría: ${tarea.categoria}</p>
        <p class="duracion">Duración: ${tarea.minutos} minutos</p>
      </article>
    `;

  }

  // Actualizamos el contador
  document.getElementById("totalTareas").textContent = tareas.length;

  // llamo a calcularTiempo para que al mostrar las tareas me calcule 
  // el tiempo total de todas las tareas y me lo muestre en el HTML
document.getElementById("tiempoTotal").textContent = calcularTiempoTotal() + " minutos";
  

}
mostrarTareas();
recuperarTareasLocal();


// =========================================
// RETO 2 · AÑADIR TAREAS
// =========================================

function agregarTarea() {

  

  // Obtenemos los valores del formulario
  const nombre = document.getElementById("nombreTarea").value;
  const categoria = document.getElementById("categoria").value;
  const minutos = Number(document.getElementById("minutos").value);

  // Creamos el objeto
  const tarea = {
    nombre: nombre,
    categoria: categoria,
    minutos: minutos
  };

  // Añadimos la tarea al array
  tareas.push(tarea);
  guardarTareasLocal();

  // Limpiamos el formulario
  document.getElementById("formularioTarea").reset();

  // Actualizamos las tareas las mostramos en el HTML 
  mostrarTareas();
 

}

// =========================================
// RETO 3 · CONTADOR DE TIEMPO DE TAREAS
// =========================================


 function calcularTiempoTotal() {
    //declaramos una variable para guardar el tiempo total
      let tiempoTareas = 0;
     for (const tarea of tareas) {
    //sumamos el tiempo de cada tarea al tiempo total
      tiempoTareas += tarea.minutos;
    }
    //devolvemos el tiempo acumulado de todas las tareas para luego poderlo mostrar en el HTML
    return tiempoTareas;
    
  }

  //====================================
  //RETO 4 . GUARDAR TAREAS EN LOCALSTORAGE
  //====================================
  //funcion para guardar las tareas en el localstorage
  function guardarTareasLocal() {
    localStorage.setItem("tareas", JSON.stringify(tareas));
  }

  //====================================
  //RETO 5 . RECUPERAR TAREAS DEL LOCALSTORAGE
  //====================================
  
  //funcion para cargar las tareas del localstorage 
  function recuperarTareasLocal() {

  // Recuperamos el texto guardado
  const tareasGuardadas = localStorage.getItem("tareas");

  // Si existen datos guardados, los convertimos en un array
  if (tareasGuardadas) {
    tareas = JSON.parse(tareasGuardadas);
  }

}
