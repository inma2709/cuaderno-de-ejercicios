/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * Los métodos de array se aplican sobre la colección: push añade, find localiza el primer resultado y filter crea una selección.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
// // /*bucle for of
// // for (let precio of precios) {
// //     console.log(precio);
// // }*/

// // /*bucle for each recorre cada elemento del array
// // y ejecuta la función para cada uno de ellos */
// // // precios.forEach(function(precio) {
// // //     let precioIva = precio * 1.21;
// // //     console.log(precioIva);
// // // });

// // // /*array para almacenar los precios con IVA que nace fuera
// // // de la función para poder acceder a estos datos
// // // fuera del bucle for each */
// // // let preciosIva = [];
// // // /*bucle for each para calcular el IVA
// // // y almacenar los precios con IVA en el nuevo array preciosIva */
// // // precios.forEach(precio => {
// // //     let precioIva = precio * 1.21;
// // //     preciosIva.push(precioIva);
// // //     console.log(precioIva);
// // // });
// // // console.log ("array original de precios sin Iva: "+ precios);
// // // console.log("Precios con IVA:" + preciosIva);
// // /*declaración de arrays */
// // //

// // // let preciosIva=precios.map(precio => precio * 1.21);

// // // console.log("array original de precios sin Iva: "+ precios);
// // // console.log("Precios con IVA:" + preciosIva);
// // /*array con descuento del 15% */
// // let precios= [10,20,30,40];
// // // let preciosDescuento=precios.map(precio => precio * 0.85);

// // // console.log("array original de precios sin descuento: " + precios);
// // // console.log("Precios con descuento del 15%: " + preciosDescuento);

// // // let productosCaros=precios.filter(precio => precio > 25);
// // // console.log("Productos caros (precio > 25): " + productosCaros);
// // /*busca un elemento en el array y te muestra el primero que encuentra */
// // let producto30=precios.find(precio => precio === 30);
// // console.log("Producto con precio 30: " + producto30);
// // let producto45=precios.find(precio => precio === 45);
// // console.log("Producto con precio 45: " + producto45);
// // /*incluye devuelve true o false*/
// // let producto20=precios.includes(20);
// // console.log("Producto con precio 20: " + producto20);
// // /*acumulador de precios */
// // const total=precios.reduce((suma, precio) => suma + precio, 0);
// // console.log("Total de precios: " + total);

// let carrito = ["pan", "leche", "huevos"];
// let eliminado = carrito.splice(1, 2);
// console.log("Elemento eliminado: " + eliminado);
// console.log("Carrito actual: " + carrito);
// /*carrito=["pan"];*/
// carrito.splice(1, 0, "mantequilla", "queso", "tomate");
// console.log("Carrito actualizado: " + carrito);
// //carrito["pan","mantequilla","queso","tomate"]
// //meter harina detrás de mantequilla
// carrito.splice(2, 1, "harina");
// console.log("Carrito actualizado: " + carrito);
let tareas = [
  "Estudiar JavaScript",
  "Hacer ejercicios",
  "Repasar arrays"
];
/*Muestra las tareas numeradas: "Tarea 1: ...", "Tarea 2: ...".
forEach() se utiliza para recorrer cada elemento del array 
y mostrarlo con su índice.
*/
tareas.forEach((tarea, posicion) => {
  console.log("Tarea"+(posicion) + ":"+tarea);
});


