/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * Los valores de los inputs son texto. Number() los convierte a número antes de calcular.
 * return entrega un resultado desde una función para utilizarlo donde se llamó.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
/*
  PRÁCTICA: EVALUADOR DE CALIFICACIONES

  Completa los apartados indicados.
  Utilizaremos IF, ELSE IF, ELSE y SWITCH.

  La función evaluarNota() ya está preparada.
  No necesitas modificarla ni entender todavía
  cómo se crean las funciones.
*/





function evaluarNota() {
  // 1. OBTENER LOS DATOS DEL HTML
  const nombre = document.getElementById("nombre").value;
  const notaTexto = document.getElementById("nota").value;
  const nota = Number(notaTexto);

  // 2. DECLARAR VARIABLES
  let calificacion = "";
  let mensaje = "";

  // 3. COMPROBAR QUE LA NOTA ES VÁLIDA
  // Esta parte ya está resuelta.
  if (notaTexto.trim() === "" || nota < 0 || nota > 10) {
    document.getElementById("resultado").textContent =
      "Introduce una nota válida entre 0 y 10.";
    document.getElementById("mensaje").textContent = "";
    return;
  }

  // 4. TU TURNO: IF...ELSE IF...ELSE
 if (nota >= 9) {
    /*calificacion es una variable declarada anteriormente*/
    calificacion = "Sobresaliente";
  } else if (nota >= 7) {
    calificacion = "Notable";
  } else if (nota >= 6) {
    calificacion = "Bien";
  } else if (nota >= 5) {
    calificacion = "Suficiente";
  } else {
    calificacion = "Insuficiente";
  }

  // 5. TU TURNO: SWITCH
/*valoramos la variable que nos devuelve la calificacion*/
   switch(calificacion) {
    case "Sobresaliente":
/*mensaje es la variable que contendrá el mensaje correspondiente a la calificación*/
      mensaje = "¡Excelente trabajo!";
      break;
    case "Notable":
      mensaje = "Muy bien, sigue así.";
      break;
    case "Bien":
      mensaje = "Buen trabajo, pero puedes mejorar.";
      break;
    case "Suficiente":
      mensaje = "Has aprobado, pero necesitas esforzarte más.";
      break;
    case "Insuficiente":
      mensaje = "No has aprobado, necesitas estudiar más.";
      break;
    default:
      mensaje = "";
  }

  // 6. MOSTRAR RESULTADOS EN HTML
  // Esta parte ya está resuelta.
  document.getElementById("resultado").textContent =
    nombre + ", has obtenido un " + calificacion +
    " con una nota de " + nota + ".";
  document.getElementById("mensaje").textContent = mensaje;
}
