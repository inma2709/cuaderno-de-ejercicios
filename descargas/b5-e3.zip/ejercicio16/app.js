/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * return entrega un resultado desde una función para utilizarlo donde se llamó.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
/* Definición de un objeto */
function calcularTotal() {
  return this.precio * this.cantidad;
}

const falda ={
    nombre: "Falda",
    precio: 25,
    disponible: true,
    cantidad: 3,
    talla:["s","m","l"],
    calcularTotal: calcularTotal
   };

   console.log("soy el precio total de la falda: " + falda.calcularTotal()  );

const pantalon = {
    nombre: "Pantalón",
    precio: 40,
    disponible: true,
    cantidad: 2,
    calcularTotal: calcularTotal
   };

console.log("soy el precio total del pantalón: " + pantalon.calcularTotal());
// console.log(producto);

// producto.calcularTotal();
// console.log(producto.calcularTotal( ));



// console.log(producto);
// /* Accediendo a las propiedades del objeto */
// producto.nombre;
// producto.precio;
// producto.disponible;
// console.log (producto.nombre);
// console.log (producto.precio);
// console.log (producto.disponible);
// /*Añadiendo una nueva propiedad al objeto */
// producto.talla=["S", "M", "L", "XL"];
// console.log(producto.talla);
// /*Modificar una propiedad del objeto */
// producto.precio=30;
// console.log(producto.precio);
// /*Borrar una propiedad del objeto */
// delete producto.disponible;
// console.log(producto);





