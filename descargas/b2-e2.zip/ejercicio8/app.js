/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
/*Crea datos para edad, plazas disponibles, precio 
y si es estudiante. Muestra edad, plazas y precio en HTML.*/
let edad = 25;
let plazasDisponibles = 10;
let precio = 50;
let esEstudiante = true;

/*Compara las plazas con 5. Si quedan menos, 
muestra «¡Últimas plazas!»; en caso contrario, «Plazas disponibles».*/
if (plazasDisponibles < 5) {
    console.log("¡Últimas plazas!");
    document.getElementById("plazas").textContent = "¡Últimas plazas!";
} else  {
    console.log("Plazas disponibles");

    /*id "plazas" del html*/
    document.getElementById("plazas").textContent = "Plazas disponibles";

/*id "reserva" del html*/
document.getElementById("reserva").textContent = "";
}



/*Compara la edad con 18. Muestra si puede o no realizar la reserva.*/
if (edad >= 18 && plazasDisponibles > 0) {
    console.log("Puede realizar la reserva");
    document.getElementById("reserva").textContent = "Puede realizar la reserva";
} else {
    console.log("No puede realizar la reserva");
    document.getElementById("reserva").textContent = "No puede realizar la reserva";
}

/*Usa un ternario para elegir entre «Tienes descuento de estudiante» y «Precio estándar».*/
let mensaje;

mensaje = esEstudiante ? "Tienes descuento de estudiante" : "Precio estándar";
document.getElementById("precio").textContent = mensaje;
