/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
        let cantidad=100;
        let precio=100;
        /*condicion una*/
        if (cantidad>=5 && precio>0){
            console.log("Tenemos stock con un precio de " + precio + " €");
            document.getElementById("stock").textContent = "Tenemos stock con un precio de " + precio  + " €";
        } 
        /*alternativa al primer if*/
        else if (cantidad>=5 || (cantidad >0 && precio>0)){
            console.log("Quedan pocas unidades con un precio de " + precio + " €");
            document.getElementById("stock").textContent = "Quedan pocas unidades con un precio de " + precio + " €";
        } 
        /* salida si no cumple ninguna condición */
        else{
            console.log("No tenemos stock");
            document.getElementById("stock").textContent = "No tenemos stock";
        }
