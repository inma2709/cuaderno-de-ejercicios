/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * Los métodos de array se aplican sobre la colección: push añade, find localiza el primer resultado y filter crea una selección.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
/*<label>Nombre <input id="nombre" type="text"></label>
  <label>Nota <input id="nota" type="number"></label>
  <button onclick="guardarAlumno()">Guardar alumno</button>
  <p id="contador">Alumnos registrados: 0</p>
  <button onclick="mostrarNotas()">Mostrar notas</button>
  <p id="mensaje"></p>
  <p id="resultado"></p>*/
/*declara los arrays para almacenar los alumnos y sus notas*/
let alumnos = [];
let notas=[2,2,2,5,5];
notas.splice(1,2,3);
console.log ("soy notas con splice", notas);




    let nombre= document.getElementById("nombre").value;
    let nota= document.getElementById("nota").value;
    alumnos.push(nombre);
    notas.push(nota);
    /*mostrar la cantidad de alumnos que tenemos en el array alumnos*/
    document.getElementById("contador").textContent = "Alumnos registrados: " + alumnos.length;



function mostrarNotas() {
    let mensajeConNotas = "";
    for (let i = 0; i < alumnos.length; i++) {
        mensajeConNotas += alumnos[i] + ": " + notas[i] + " ";
    }
    document.getElementById("mensaje").textContent = mensajeConNotas;
}



