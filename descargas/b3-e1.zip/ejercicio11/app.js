/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * Los valores de los inputs son texto. Number() los convierte a número antes de calcular.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
// // let condicion=1;

// // while (condicion<6){

// //     console.log ("soy menor a seis");
// //     console.log(condicion);
// //     condicion=condicion+1;// actualizo el contador 
// //     //condicion++ condicion+=2

// // }

// // /*adivinar un numero aleatorio, el usuario tiene que introducir un número hasta que adivine el número aleatorio*/
// // let numeroAleatorio=8;
// // let numeroIntroducido=Number(prompt("Introduce un número menor que 10"));


// // while (numeroIntroducido!=numeroAleatorio){
// //     numeroIntroducido=Number(prompt("Introduce un número menor que 10"));
// //    if (numeroIntroducido===numeroAleatorio){
// //        alert("Has adivinado el número");
// //    }
// // }

// // /*bucle while para saludar tres veces*/

// // let saludo=0;
// // /*saludo entra en el bucle cumple la condicion*/
// // while (saludo<3){ 
// // /*ejecuta el codigo del bucle*/
// //     console.log("Hola");
    
// // /*saludo se actualiza para que no sea infinito el bucle y sólo salude 3 veces*/
// //     saludo=saludo+1; /*saludo++*/

// //     console.log ("soy saludo actualizado y valgo: "+saludo);

// // }

// // /*hacer un bucle while que cuente del 1 al 5 y lo muestre por consola*/

// // /*declaracion e iniciliacion de variable contador*/
// // let contador=1;
// // /*condicion del bucle ¿hasta cuando se va a ejecutar el bucle?*/
// // while(contador<=5){

// //     console.log(contador);
// //     /*actualizacion del contador que posibilidades tengo de terminar el bucle*/
// //     contador++; /*contador=contador+1*/

    
// // }

// // // /*usa el bucle for y cuenta del 1 al 7*/

// // for (let i=1; i<=7; i++){
// //     console.log(i);
// // }

// // let i=1;
// // while (i<=7){
// //     console.log(i);
// //     i++; 
// // }

// /*mostrar 2, 4, 6, 8 y 10. Escribe un for que empiece en 2 y avance de dos en dos.*/

// // for (let i=2; i<=10; i+=2){
// //     console.log(i);
// // }

// /*Con numero = 10 y condición numero < 5, ¿cuántas veces se ejecutará el bucle while?*/

// // let numero=10;

// // do{
// //     console.log ("hola soy el bucle do while " + numero);    
// //     numero++;
// // } while(numero<5);

// /*Crea un programa en JavaScript que recorra los números del 1 al 20 y:
// - Compruebe si cada número es par.
// - Muestre en consola los números pares.
// - Cuente cuántos números pares se han encontrado.
// - Muestre el resultado final.*/

// for (let numero=1; numero<20; numero++){    
   

//     /*este condicional comprueba si el número es par, si lo es lo muestra por consola*/

//     if (numero % 2 === 0) {
//                 console.log("este es un numero par: " + numero);
//             }   
            
            
// }   /*el bucle termina en esta llave*/


/*quiero un programa que muestre si las primeras diez personas pueden entrar
sólo pueden entrar si tienen 18 años o más*/
/*estas personas su edad se va a multiplicar por 3 en cada persona, 
la primera tiene un año*/
let edad=1;

for (let persona=1; persona<=10; persona++){
    edad=edad*3;
    console.log("la edad de la persona " + persona + " es: " + edad);
    if (edad>=18){
        console.log("la persona " + persona + " puede pasar");
    }else{
        console.log("la persona " + persona + " no puede pasar");
    }   
}




/*quiero un programa que muestre si las primeras diez personas pueden entrar*/
const mensaje = document.getElementById("mensaje");
let puedenPasar = 0;
 
for (let persona = 1; persona <= 10; persona += 1) {
    
  const edad = Number(prompt("Persona " + persona + ": escribe tu edad"));
 
  if (edad >= 18) {
    alert("La persona " + persona + " puede pasar.");
    puedenPasar += 1;/*el numero de personas que pueden pasar xq tienen mas de 18*/
    console.log("La persona " + persona + " puede pasar.");
  }else{
    console.log("La persona " + persona + " no puede pasar.");
    alert("La persona " + persona + " no puede pasar.");
  }
}
 
if (puedenPasar === 10) {
  mensaje.textContent = "Las 10 personas pueden entrar.";
} else {
  mensaje.textContent = "Solo pueden entrar " + puedenPasar + " de 10.";
 
}

 






