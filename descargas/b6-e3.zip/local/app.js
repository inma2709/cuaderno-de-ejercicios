/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * Al iniciar, se recuperan los datos guardados y se actualiza el array. Al añadir un dato: push(), guardar en localStorage y volver a mostrar el listado.
 * JSON.stringify convierte arrays u objetos en texto para guardarlos; JSON.parse recupera de nuevo su estructura.
 * Los bucles recorren los datos uno a uno. La variable declarada en cada vuelta representa el elemento actual.
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 * Los métodos de array se aplican sobre la colección: push añade, find localiza el primer resultado y filter crea una selección.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
alumnos=[
    { nombre: "Juan", edad: 20 },
    { nombre: "María", edad: 22 },
    { nombre: "Pedro", edad: 21 }
]

//mostramos los alumnos en el navegador

// Seleccionamos el contenedor una sola vez
const listaAlumnos = document.getElementById("alumnos");


alumnos = recuperarAlumnos()||alumnos; // Si hay alumnos guardados en el localStorage, los usamos, si no, usamos la lista inicial

// Recorremos el array y mostramos los alumnos
for (const alumno of alumnos) {
   
  listaAlumnos.innerHTML += `<p>${alumno.nombre} : ${alumno.edad} años</p>`;
  guardarAlumnos(); // Guardamos los alumnos en el localStorage
}



//queremos guardar esta lista de alumnos en el localStorage para que persista aunque cerremos el navegador
// Guardamos la lista de alumnos en el localStorage
function guardarAlumnos() {
  // 1. Convertimos el array en texto JSON
  const alumnosJSON = JSON.stringify(alumnos);

  // 2. Guardamos el texto en localStorage
  localStorage.setItem("alumnosGuardadosLocal", alumnosJSON);
}
//podemos hacerlo mas breve en una sola linea guardamos y convertimos a JSON al mismo tiempo
//localStorage.setItem("alumnos", JSON.stringify(alumnos));

// Recuperamos la lista de alumnos del localStorage para mostrarla en el navegador
function recuperarAlumnos() {
  const alumnosGuardados = localStorage.getItem("alumnosGuardadosLocal");

  if (alumnosGuardados) {
    alumnos = JSON.parse(alumnosGuardados);
  }
}

//vamos a crear una función para agregar un nuevo alumno a la lista
agregarAlumno = () => {
  const nombre = document.getElementById("nombre").value;
  const edad = document.getElementById("edad").value;

  if (nombre && edad) {
    alumnos.push ({nombre,edad});
    guardarAlumnos();
    listaAlumnos.innerHTML += `<p>${nombre} : ${edad} años</p>`;
  } else {
    alert("Por favor, complete todos los campos.");
  }

  document.getElementById("nombre").value = "";
  document.getElementById("edad").value = "";

}

