/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */


let muchosParrafos=document.querySelectorAll(".mensaje");

console.log(muchosParrafos);

muchosParrafos.forEach(miParrafito=>{

    miParrafito.textContent="soy un parrafo capturado por un querySelectorAll"


})

let hora= new Date().getHours() + ":" 
+ new Date().getMinutes() + ":" 
+ new Date().getSeconds() + " ." 
+ new Date().getDate() + "/" 
+ (new Date().getMonth() + 1) 
+ "/" + new Date().getFullYear() + " aqui soy UTC:" 
+ new Date().toUTCString();

if(hora < "12:00")
    document.getElementById("saludo").textContent = 
"Buenos días. La hora actual es: " + hora 
else if(hora < "18:00")
    document.getElementById("saludo").textContent = 
"<strong> Buenas tardes. La hora actual es: " + hora + "</strong>";
else
    document.getElementById("saludo").textContent = 
"Buenas noches. La hora actual es: " + hora;

/* Función para mostrar la ficha del curso seleccionado */

function mostrarCurso(opcion) {
  const ficha = document.getElementById("ficha");

  if (opcion === "html") {
    ficha.innerHTML = "<h3>HTML esencial</h3>" +
    "<p>Aprende a estructurar páginas web.</p>" +
    "<p>Este curso es fundamental para cualquier desarrollador web.</p>";
  } else {
    ficha.innerHTML = "<h3>JavaScript esencial</h3>" +
    "<p>Haz que tus páginas respondan.</p>";
  }
}




