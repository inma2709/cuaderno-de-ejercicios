/*
 * SOLUCIÓN RECONSTRUIDA · ACTIVIDAD GESTOR DE CITAS
 *
 * La plantilla mantiene app.js vacío para que puedas realizar la actividad.
 * Esta solución usa los identificadores que ya existen en index.html.
 * Al añadir una cita: leemos los inputs, creamos un objeto, hacemos push()
 * y volvemos a pintar el listado para que DOM y array estén sincronizados.
 */

let citas = [
  { cliente: "Marta Ruiz", servicio: "Corte", precio: 25 },
  { cliente: "Juan Pérez", servicio: "Peinado", precio: 30 }
];

const listaCitas = document.getElementById("listaCitas");
const totalCitas = document.getElementById("totalCitas");
const importeTotal = document.getElementById("importeTotal");
const formulario = document.getElementById("formularioCita");
const nombreCliente = document.getElementById("nombreCliente");
const servicio = document.getElementById("servicio");
const precio = document.getElementById("precio");
const mensaje = document.getElementById("mensaje");

// Recorre el array y crea una tarjeta por cada cita registrada.
function mostrarCitas() {
  listaCitas.innerHTML = "";
  let total = 0;

  for (const cita of citas) {
    listaCitas.innerHTML += `
      <article class="cita">
        <h3>${cita.cliente}</h3>
        <p>${cita.servicio}</p>
        <p class="precio">${cita.precio} €</p>
      </article>
    `;
    total += cita.precio;
  }

  totalCitas.textContent = citas.length;
  importeTotal.textContent = total + " €";
}

// Lee los datos del formulario y añade una nueva cita al array.
function agregarCita() {
  const nuevaCita = {
    cliente: nombreCliente.value.trim(),
    servicio: servicio.value,
    precio: Number(precio.value)
  };

  if (!nuevaCita.cliente || !nuevaCita.servicio || nuevaCita.precio <= 0) {
    mensaje.textContent = "Completa los datos de la cita.";
    return;
  }

  citas.push(nuevaCita);
  formulario.reset();
  mensaje.textContent = "Cita añadida correctamente.";
  mostrarCitas();
}

mostrarCitas();
