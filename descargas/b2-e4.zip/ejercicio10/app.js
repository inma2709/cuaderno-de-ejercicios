/*
 * REVISIÓN DIDÁCTICA DEL CUADERNO
 *
 * Esta es la solución trabajada en clase, conservada con sus nombres originales.
 * Ideas clave de esta práctica:
 * textContent escribe texto seguro; innerHTML se utiliza aquí para crear la estructura HTML dinámica del ejercicio.
 * Primero se seleccionan los elementos del HTML; después las funciones cambian su contenido o leen sus valores.
 *
 * Estudia cada bloque, modifica un dato y observa qué parte de la página cambia.
 */
/*Una persona quiere decidir qué actividad puede hacer según el dinero 
que tiene y si hace buen tiempo.*/
/*2. Primera parte: tomar una decisión con if
Completa un condicional que asigne un valor a tipoPlan siguiendo estas reglas:
Condición	Valor de tipoPlan
Tiene 20 € o más y hace buen tiempo	"excursion"
Tiene 10 € o más, pero no cumple la condición anterior	"cine"
Tiene menos de 10 €	"casa"
Para resolverlo, deben utilizar if, else if, else, >= y &&.*/

let tipoPlan;
let dinero = 15;
let buenTiempo = true;

if (dinero >= 20 && buenTiempo) {
    tipoPlan = "excursion";
    console.log(tipoPlan);
} else if (dinero >= 10) {
    tipoPlan = "cine";
    console.log(tipoPlan);

} else {
    tipoPlan = "casa";
    console.log(tipoPlan);
}

switch(tipoPlan){
    case "excursion":
        console.log ("Te vas de excursion");
        document.getElementById("actividad").textContent = "Te vas de excursion";
        break;
    case "cine":
        console.log("Vas al cine");
        document.getElementById("actividad").textContent = "Vas al cine";
        break;
    case "casa":
        console.log("Te quedas en casa");
        document.getElementById("actividad").textContent = "Te quedas en casa";
        break;
}
